package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.VideoEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class LockState {
    SETUP_PASSWORD,
    SETUP_RECOVERY,
    ENTER_PASSWORD,
    UNLOCKED,
    RECOVERY_RESET
}

class VideoViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: AppRepository

    val allVideos: StateFlow<List<VideoEntity>>

    private val _lockState = MutableStateFlow(LockState.ENTER_PASSWORD)
    val lockState: StateFlow<LockState> = _lockState.asStateFlow()

    private val _passcode = MutableStateFlow("")
    val passcode: StateFlow<String> = _passcode.asStateFlow()

    private val _tempPasscode = MutableStateFlow("")
    val tempPasscode: StateFlow<String> = _tempPasscode.asStateFlow()

    private val _recoveryQuestion = MutableStateFlow("What is the name of your first pet?")
    val recoveryQuestion: StateFlow<String> = _recoveryQuestion.asStateFlow()

    private val _recoveryAnswer = MutableStateFlow("")
    val recoveryAnswer: StateFlow<String> = _recoveryAnswer.asStateFlow()

    private val _recoveryAnswerInput = MutableStateFlow("")
    val recoveryAnswerInput: StateFlow<String> = _recoveryAnswerInput.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _activeVideo = MutableStateFlow<VideoEntity?>(null)
    val activeVideo: StateFlow<VideoEntity?> = _activeVideo.asStateFlow()

    // Represents if the secure RED button is currently held down
    private val _videoPlaying = MutableStateFlow(false)
    val videoPlaying: StateFlow<Boolean> = _videoPlaying.asStateFlow()

    private val _faceSecurityEnabled = MutableStateFlow(false)
    val faceSecurityEnabled: StateFlow<Boolean> = _faceSecurityEnabled.asStateFlow()

    private val _registeredFaceRatio = MutableStateFlow<Float?>(null)
    val registeredFaceRatio: StateFlow<Float?> = _registeredFaceRatio.asStateFlow()

    private val _faceDetectionStatus = MutableStateFlow("Inactive")
    val faceDetectionStatus: StateFlow<String> = _faceDetectionStatus.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database)
        allVideos = repository.allVideos.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        checkSecurityConfig()
    }

    private fun checkSecurityConfig() {
        viewModelScope.launch {
            val savedPassword = repository.getConfig("password")
            val savedQuestion = repository.getConfig("recovery_question")
            val savedAnswer = repository.getConfig("recovery_answer")

            if (savedPassword.isNullOrEmpty()) {
                _lockState.value = LockState.SETUP_PASSWORD
            } else {
                _lockState.value = LockState.ENTER_PASSWORD
                _recoveryQuestion.value = savedQuestion ?: "What is the name of your first pet?"
                _recoveryAnswer.value = savedAnswer ?: ""
            }

            val savedFaceEnabled = repository.getConfig("face_security_enabled") == "true"
            val savedFaceRatio = repository.getConfig("registered_face_ratio")?.toFloatOrNull()
            _faceSecurityEnabled.value = savedFaceEnabled
            _registeredFaceRatio.value = savedFaceRatio

            // Prep defaults if video library is empty
            viewModelScope.launch {
                repository.allVideos.collect { videos ->
                    if (videos.isEmpty()) {
                        insertDefaultVideos()
                    } else if (_activeVideo.value == null) {
                        _activeVideo.value = videos.firstOrNull()
                    }
                }
            }
        }
    }

    private suspend fun insertDefaultVideos() {
        val defaults = listOf(
            VideoEntity(videoId = "Ke90Tje7VS0", title = "Majestic Nature - 4K Drone Footage", durationText = "03:15"),
            VideoEntity(videoId = "tVixyIyeAnY", title = "Lofi Hip Hop Radio - Beats to Study/Relax", durationText = "24:00"),
            VideoEntity(videoId = "dQw4w9WgXcQ", title = "Never Gonna Give You Up - Rick Astley", durationText = "03:32"),
            VideoEntity(videoId = "9bZkp7q19f0", title = "PSY - GANGNAM STYLE", durationText = "04:12")
        )
        for (video in defaults) {
            repository.insertVideo(video)
        }
    }

    fun handleKeyPress(digit: String) {
        _authError.value = null
        if (_passcode.value.length < 6) {
            _passcode.value += digit
        }
    }

    fun handleDeletePress() {
        _authError.value = null
        if (_passcode.value.isNotEmpty()) {
            _passcode.value = _passcode.value.dropLast(1)
        }
    }

    fun handleClearPress() {
        _passcode.value = ""
        _authError.value = null
    }

    fun submitPasscode() {
        viewModelScope.launch {
            val savedPassword = repository.getConfig("password") ?: ""
            if (_passcode.value == savedPassword) {
                _lockState.value = LockState.UNLOCKED
                _passcode.value = ""
                _authError.value = null
            } else {
                _authError.value = "Incorrect passcode. Please try again."
                _passcode.value = ""
            }
        }
    }

    fun submitSetupPassword() {
        if (_passcode.value.length < 4) {
            _authError.value = "Password must be at least 4 digits"
            return
        }
        _tempPasscode.value = _passcode.value
        _passcode.value = ""
        _lockState.value = LockState.SETUP_RECOVERY
        _authError.value = null
    }

    fun submitSecuritySetup(question: String, answer: String) {
        if (answer.trim().isEmpty()) {
            _authError.value = "Answer cannot be empty"
            return
        }
        viewModelScope.launch {
            repository.setConfig("password", _tempPasscode.value)
            repository.setConfig("recovery_question", question)
            repository.setConfig("recovery_answer", answer.trim().lowercase())

            _recoveryQuestion.value = question
            _recoveryAnswer.value = answer.trim().lowercase()
            _passcode.value = ""
            _tempPasscode.value = ""
            _lockState.value = LockState.UNLOCKED
            _authError.value = null
        }
    }

    fun onAnswerInputChanged(input: String) {
        _recoveryAnswerInput.value = input
        _authError.value = null
    }

    fun submitRecoveryAnswer() {
        if (_recoveryAnswerInput.value.trim().lowercase() == _recoveryAnswer.value.trim().lowercase()) {
            _lockState.value = LockState.SETUP_PASSWORD
            _recoveryAnswerInput.value = ""
            _passcode.value = ""
            _authError.value = null
        } else {
            _authError.value = "Incorrect security recovery answer."
        }
    }

    fun navigateToRecovery() {
        _lockState.value = LockState.RECOVERY_RESET
        _authError.value = null
        _passcode.value = ""
    }

    fun navigateToEnterPassword() {
        _lockState.value = LockState.ENTER_PASSWORD
        _authError.value = null
        _passcode.value = ""
    }

    fun resetLock() {
        viewModelScope.launch {
            repository.deleteConfig("password")
            repository.deleteConfig("recovery_question")
            repository.deleteConfig("recovery_answer")
            _lockState.value = LockState.SETUP_PASSWORD
            _passcode.value = ""
            _tempPasscode.value = ""
            _authError.value = null
        }
    }

    fun selectVideo(video: VideoEntity) {
        _activeVideo.value = video
    }

    fun addVideo(urlOrId: String, title: String) {
        viewModelScope.launch {
            val videoId = extractYoutubeVideoId(urlOrId)
            if (videoId != null) {
                val newVideo = VideoEntity(
                    videoId = videoId,
                    title = title.ifBlank { "Custom Video ($videoId)" }
                )
                repository.insertVideo(newVideo)
                _activeVideo.value = newVideo
            }
        }
    }

    fun removeVideo(video: VideoEntity) {
        viewModelScope.launch {
            repository.deleteVideo(video)
            if (_activeVideo.value?.id == video.id) {
                _activeVideo.value = allVideos.value.firstOrNull { it.id != video.id }
            }
        }
    }

    fun setVideoPlaying(playing: Boolean) {
        _videoPlaying.value = playing
    }

    fun setFaceSecurityEnabled(enabled: Boolean) {
        viewModelScope.launch {
            _faceSecurityEnabled.value = enabled
            repository.setConfig("face_security_enabled", enabled.toString())
        }
    }

    fun registerFace(ratio: Float) {
        viewModelScope.launch {
            _registeredFaceRatio.value = ratio
            repository.setConfig("registered_face_ratio", ratio.toString())
        }
    }

    fun clearRegisteredFace() {
        viewModelScope.launch {
            _registeredFaceRatio.value = null
            repository.deleteConfig("registered_face_ratio")
            _faceSecurityEnabled.value = false
            repository.setConfig("face_security_enabled", "false")
        }
    }

    fun setFaceDetectionStatus(status: String) {
        _faceDetectionStatus.value = status
    }

    fun extractYoutubeVideoId(url: String): String? {
        val cleanUrl = url.trim()
        if (cleanUrl.length == 11 && !cleanUrl.contains("/") && !cleanUrl.contains("?")) {
            return cleanUrl // Direct 11-char ID
        }

        // Regex supporting common Youtube structures
        val regex = "^(?:https?:\\/\\/)?(?:www\\.)?(?:youtube\\.com\\/(?:[^\\/\\n\\s]+\\/\\S+\\/|(?:v|e(?:mbed)?)\\/|\\S*?[?&]v=)|youtu\\.be\\/)([a-zA-Z0-9_-]{11})".toRegex(RegexOption.IGNORE_CASE)
        val matchResult = regex.find(cleanUrl)
        return matchResult?.groups?.get(1)?.value
    }
}
