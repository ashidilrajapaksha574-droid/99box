package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.material.icons.filled.MoreVert
import com.example.ui.theme.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.viewmodel.VideoViewModel
import androidx.compose.ui.platform.LocalContext
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.isGranted
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Box99Screen(
    viewModel: VideoViewModel,
    onNavigateToLibrary: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeVideo by viewModel.activeVideo.collectAsState()
    val videoPlaying by viewModel.videoPlaying.collectAsState()
    val faceSecurityEnabled by viewModel.faceSecurityEnabled.collectAsState()
    val registeredFaceRatio by viewModel.registeredFaceRatio.collectAsState()
    val faceDetectionStatus by viewModel.faceDetectionStatus.collectAsState()

    var isFaceRegisteringMode by remember { mutableStateOf(false) }
    var isFaceConsoleExpanded by remember { mutableStateOf(false) }
    var isMenuExpanded by remember { mutableStateOf(false) }
    var showInstallDialog by remember { mutableStateOf(false) }

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }

    // Pulsing animation for the hold overlay placeholder
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    // Button scale animation when pressed
    val buttonScale by animateFloatAsState(
        targetValue = if (videoPlaying) 0.88f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "button_scale"
    )

    val infiniteTransitionRotate = rememberInfiniteTransition(label = "rotate")
    val rotationAngle by infiniteTransitionRotate.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Handle play and pause trigger
    LaunchedEffect(videoPlaying) {
        val webView = webViewInstance ?: return@LaunchedEffect
        if (videoPlaying) {
            webView.evaluateJavascript("playVideo()", null)
        } else {
            webView.evaluateJavascript("pauseVideo()", null)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header (Professional Polish Style)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                color = MaterialTheme.colorScheme.secondary,
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Shield",
                            tint = PolishDarkText,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Secure Session",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = (-0.2).sp
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "ENCRYPTION ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            ),
                            color = PolishTextSecondary
                        )
                    }
                }
                Box {
                    IconButton(onClick = { isMenuExpanded = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More options",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    DropdownMenu(
                        expanded = isMenuExpanded,
                        onDismissRequest = { isMenuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Install App on Phone") },
                            onClick = {
                                isMenuExpanded = false
                                showInstallDialog = true
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Install Information"
                                )
                            }
                        )
                    }
                }
            }
            HorizontalDivider(
                color = PolishBorder,
                thickness = 1.dp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        FaceSecurityConsoleCard(
            viewModel = viewModel,
            faceSecurityEnabled = faceSecurityEnabled,
            registeredFaceRatio = registeredFaceRatio,
            faceDetectionStatus = faceDetectionStatus,
            isFaceRegisteringMode = isFaceRegisteringMode,
            onRegisteringModeChanged = { isFaceRegisteringMode = it },
            isFaceConsoleExpanded = isFaceConsoleExpanded,
            onConsoleExpandedChanged = { isFaceConsoleExpanded = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        )

        // Active video or Empty State
        if (activeVideo == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 24.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(24.dp))
                    .border(BorderStroke(1.dp, PolishBorder), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "No video selected",
                        tint = PolishTextSecondary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Active Video Selected",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Go to the Library tab to add or select a secure YouTube video.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = PolishTextSecondary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = onNavigateToLibrary,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Open Video Library", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            val video = activeVideo!!
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Video Container with Secure Overlay (Professional Polish Style)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.77f) // aspect-video
                        .clip(RoundedCornerShape(28.dp))
                        .background(Color(0xFF1A1C18))
                        .border(
                            border = BorderStroke(
                                width = 1.5.dp,
                                color = if (videoPlaying) MaterialTheme.colorScheme.primary else PolishBorder
                            ),
                            shape = RoundedCornerShape(28.dp)
                        )
                ) {
                    // 1. YouTube Iframe Webview
                    val htmlContent = remember(video.videoId) { getYoutubeHtml(video.videoId) }

                    YoutubeWebView(
                        htmlContent = htmlContent,
                        onWebViewCreated = { webViewInstance = it },
                        modifier = Modifier.fillMaxSize()
                    )

                    // 2. Security Cover overlay
                    androidx.compose.animation.AnimatedVisibility(
                        visible = !videoPlaying,
                        enter = fadeIn(animationSpec = tween(100)),
                        exit = fadeOut(animationSpec = tween(50))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF1A1C18))
                                .testTag("secure_guard_overlay"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                val isFaceBlocked = faceDetectionStatus.contains("Shield Triggered")
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .background(
                                            color = if (isFaceBlocked) Color(0xFFC62828) else MaterialTheme.colorScheme.primary,
                                            shape = CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "Video is Hidden",
                                        tint = Color.White,
                                        modifier = Modifier
                                            .size(32.dp)
                                            .scale(if (!videoPlaying) pulseAlpha else 1f)
                                    )
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (isFaceBlocked) "ACCESS DENIED • FACE SHIELD" else "LOCKED • HOLD TRIGGER",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.5.sp
                                    ),
                                    color = if (isFaceBlocked) Color(0xFFE57373) else Color.White
                                )
                            }
                        }
                    }

                    // 3. Bottom Left video title overlay (Pill)
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.5f),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                        ) {
                            Text(
                                text = video.title,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                                color = Color.White.copy(alpha = 0.9f),
                                maxLines = 1,
                                modifier = Modifier
                                    .widthIn(max = 180.dp)
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Controller details below player
                Text(
                    text = "99box Controller",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Secure protocol enabled. Video only visible while trigger is engaged.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = PolishTextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
            }
        }

        // Bottom Secure Red Button Area (Professional Polish Design)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(144.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Dashed Rotating Ring
                Box(
                    modifier = Modifier
                        .size(128.dp)
                        .rotate(rotationAngle)
                        .drawBehind {
                            drawCircle(
                                color = PolishTertiary.copy(alpha = 0.3f),
                                style = Stroke(
                                    width = 2.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                                )
                            )
                        }
                )

                // Central Active Trigger Button
                Box(
                    modifier = Modifier
                        .size(104.dp)
                        .scale(buttonScale)
                        .clip(CircleShape)
                        .background(PolishTertiary)
                        .border(
                            border = BorderStroke(8.dp, PolishRedContainer),
                            shape = CircleShape
                        )
                        .pointerInput(activeVideo) {
                            if (activeVideo != null) {
                                detectTapGestures(
                                    onPress = {
                                        viewModel.setVideoPlaying(true)
                                        try {
                                            awaitRelease()
                                        } finally {
                                            viewModel.setVideoPlaying(false)
                                        }
                                    }
                                )
                            }
                        }
                        .testTag("hold_to_play_red_button"),
                    contentAlignment = Alignment.Center
                ) {
                    // Modern square visual inside the button (White outline)
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .border(3.5.dp, Color.White, RoundedCornerShape(4.dp))
                    )
                }
            }

            Text(
                text = if (videoPlaying) "RELEASE TO SECURE" else "HOLD TO WATCH",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.5.sp
                ),
                color = PolishTertiary,
                modifier = Modifier.padding(top = 12.dp)
            )
        }
    }

    if (showInstallDialog) {
        AlertDialog(
            onDismissRequest = { showInstallDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Install 99box on Your Phone",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "To run this application natively on your real physical phone, please follow these simple steps:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "1. Build and Download APK",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "In the top-right menu panel of this Google AI Studio browser interface, click on the Settings/Export option and select 'Download APK' (or 'Build APK'). This generates a ready-to-run Android .apk file.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            HorizontalDivider(color = PolishBorder.copy(alpha = 0.5f))

                            Text(
                                text = "2. Transfer to your Phone",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Send the downloaded APK file to your personal phone using Google Drive, Email, USB cable, or any messaging application.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            HorizontalDivider(color = PolishBorder.copy(alpha = 0.5f))

                            Text(
                                text = "3. Install & Play",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Tap the APK on your phone. If prompted, grant permission to 'Install from Unknown Sources' to complete the native setup.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showInstallDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Got It", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YoutubeWebView(
    htmlContent: String,
    onWebViewCreated: (WebView) -> Unit,
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                settings.apply {
                    javaScriptEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    domStorageEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                }
                onWebViewCreated(this)
                loadDataWithBaseURL("https://www.youtube.com", htmlContent, "text/html", "UTF-8", null)
            }
        },
        update = { webView ->
            // Re-load only if content changes (handled by key videoId inside remember in caller)
            // But sometimes we need to make sure the load matches.
        },
        modifier = modifier
    )
}

private fun getYoutubeHtml(videoId: String): String {
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body, html { margin: 0; padding: 0; width: 100%; height: 100%; background-color: black; overflow: hidden; }
            iframe { width: 100%; height: 100%; border: none; }
        </style>
    </head>
    <body>
        <div id="player"></div>
        <script>
            var tag = document.createElement('script');
            tag.src = "https://www.youtube.com/iframe_api";
            var firstScriptTag = document.getElementsByTagName('script')[0];
            firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

            var player;
            function onYouTubeIframeAPIReady() {
                player = new YT.Player('player', {
                    height: '100%',
                    width: '100%',
                    videoId: '$videoId',
                    playerVars: {
                        'playsinline': 1,
                        'controls': 0,
                        'rel': 0,
                        'showinfo': 0,
                        'modestbranding': 1,
                        'autoplay': 1,
                        'mute': 0
                    },
                    events: {
                        'onReady': onPlayerReady
                    }
                });
            }

            function onPlayerReady(event) {
                // Ensure media autoplay
                if (player && player.playVideo) {
                    player.playVideo();
                }
            }

            function playVideo() {
                if (player && player.playVideo) {
                    player.playVideo();
                }
            }

            function pauseVideo() {
                if (player && player.pauseVideo) {
                    player.pauseVideo();
                }
            }
        </script>
    </body>
    </html>
    """.trimIndent()
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun FaceSecurityConsoleCard(
    viewModel: VideoViewModel,
    faceSecurityEnabled: Boolean,
    registeredFaceRatio: Float?,
    faceDetectionStatus: String,
    isFaceRegisteringMode: Boolean,
    onRegisteringModeChanged: (Boolean) -> Unit,
    isFaceConsoleExpanded: Boolean,
    onConsoleExpandedChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val cameraPermissionState = rememberPermissionState(android.Manifest.permission.CAMERA)
    var currentDetectedRatio by remember { mutableStateOf<Float?>(null) }

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        border = BorderStroke(1.dp, PolishBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header row (clickable to expand/collapse)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onConsoleExpandedChanged(!isFaceConsoleExpanded) },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                color = if (faceSecurityEnabled) Color(0xFF2E7D32).copy(alpha = 0.2f) else PolishBorder.copy(alpha = 0.3f),
                                shape = CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Face Security",
                            tint = if (faceSecurityEnabled) Color(0xFF4CAF50) else PolishTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Face Auto-Shield System",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = if (faceSecurityEnabled) "Watchdog Active • Protecting Player" else "Watchdog Disabled",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (faceSecurityEnabled) Color(0xFF4CAF50) else PolishTextSecondary
                        )
                    }
                }
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Quick status badge
                    Surface(
                        color = if (faceSecurityEnabled) Color(0xFF2E7D32).copy(alpha = 0.15f) else Color.DarkGray,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (faceSecurityEnabled) "SECURE" else "OFF",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (faceSecurityEnabled) Color(0xFF81C784) else Color.LightGray,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = if (isFaceConsoleExpanded) "▲" else "▼",
                        style = MaterialTheme.typography.bodySmall,
                        color = PolishTextSecondary
                    )
                }
            }

            AnimatedVisibility(
                visible = isFaceConsoleExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    HorizontalDivider(color = PolishBorder, modifier = Modifier.padding(bottom = 12.dp))

                    if (!cameraPermissionState.status.isGranted) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "The Auto-Shield uses your front camera to automatically hide the video if anyone else looks at the screen, or if you look away.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = PolishTextSecondary,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            Button(
                                onClick = { cameraPermissionState.launchPermissionRequest() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("Grant Camera Permission", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Camera preview block
                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, if (faceSecurityEnabled) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                CameraPreviewWithFaceDetection(
                                    viewModel = viewModel,
                                    isRegistering = isFaceRegisteringMode,
                                    onFaceRegistered = { currentDetectedRatio = it },
                                    modifier = Modifier.fillMaxSize()
                                )
                                
                                // Beautiful scanning laser effect overlay
                                val infiniteTransition = rememberInfiniteTransition(label = "laser")
                                val laserY by infiniteTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = 1f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(2000, easing = LinearEasing),
                                        repeatMode = RepeatMode.Reverse
                                    ),
                                    label = "laser_y"
                                )
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val canvasHeight = this.size.height
                                    val canvasWidth = this.size.width
                                    val y = canvasHeight * laserY
                                    drawLine(
                                        color = if (faceSecurityEnabled) Color(0xFF81C784) else Color(0xFF00E6FF),
                                        start = androidx.compose.ui.geometry.Offset(0f, y),
                                        end = androidx.compose.ui.geometry.Offset(canvasWidth, y),
                                        strokeWidth = 2.dp.toPx()
                                    )
                                }
                            }

                            // Info and switch block
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "Watchdog Status:",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = PolishTextSecondary
                                )
                                Text(
                                    text = faceDetectionStatus.uppercase(),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = when {
                                        faceDetectionStatus.contains("Match", ignoreCase = true) -> Color(0xFF81C784)
                                        faceDetectionStatus.contains("Shield", ignoreCase = true) || faceDetectionStatus.contains("Unauthorized", ignoreCase = true) -> Color(0xFFE57373)
                                        else -> MaterialTheme.colorScheme.onBackground
                                    }
                                )

                                if (registeredFaceRatio != null) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Enable Auto-Shield",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                        Switch(
                                            checked = faceSecurityEnabled,
                                            onCheckedChange = { viewModel.setFaceSecurityEnabled(it) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color(0xFF4CAF50),
                                                checkedTrackColor = Color(0xFF2E7D32).copy(alpha = 0.5f)
                                            )
                                        )
                                    }
                                } else {
                                    Text(
                                        text = "Please register your face baseline to activate protection.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = PolishTextSecondary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (isFaceRegisteringMode) {
                                Button(
                                    onClick = {
                                        val ratio = currentDetectedRatio
                                        if (ratio != null) {
                                            viewModel.registerFace(ratio)
                                            onRegisteringModeChanged(false)
                                            viewModel.setFaceDetectionStatus("Face Saved Successfully")
                                        }
                                    },
                                    enabled = currentDetectedRatio != null,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Capture Baseline", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onRegisteringModeChanged(false) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Cancel")
                                }
                            } else {
                                Button(
                                    onClick = { onRegisteringModeChanged(true) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = if (registeredFaceRatio == null) "Register Face" else "Recalibrate Face",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                if (registeredFaceRatio != null) {
                                    OutlinedButton(
                                        onClick = { viewModel.clearRegisteredFace() },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE57373)),
                                        border = BorderStroke(1.dp, Color(0xFFE57373).copy(alpha = 0.5f)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Clear Registration")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CameraPreviewWithFaceDetection(
    viewModel: VideoViewModel,
    isRegistering: Boolean,
    onFaceRegistered: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }
    
    val faceDetector = remember {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .build()
        FaceDetection.getClient(options)
    }

    var consecutiveMisses by remember { mutableStateOf(0) }
    val faceSecurityEnabled by viewModel.faceSecurityEnabled.collectAsState()
    val registeredRatio by viewModel.registeredFaceRatio.collectAsState()
    val videoPlaying by viewModel.videoPlaying.collectAsState()

    val isDisposed = remember { booleanArrayOf(false) }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            isDisposed[0] = true
            try {
                if (cameraProviderFuture.isDone) {
                    val cameraProvider = cameraProviderFuture.get()
                    cameraProvider.unbindAll()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            try {
                faceDetector.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
            
            cameraProviderFuture.addListener({
                if (isDisposed[0]) return@addListener
                val cameraProvider = cameraProviderFuture.get()
                
                val preview = Preview.Builder().build().apply {
                    setSurfaceProvider(previewView.surfaceProvider)
                }
                
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    
                imageAnalysis.setAnalyzer(ContextCompat.getMainExecutor(ctx)) { imageProxy ->
                    if (isDisposed[0]) {
                        imageProxy.close()
                        return@setAnalyzer
                    }
                    @SuppressLint("UnsafeOptInUsageError")
                    val mediaImage = imageProxy.image
                    if (mediaImage != null) {
                        val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                        faceDetector.process(image)
                            .addOnSuccessListener { faces ->
                                if (isDisposed[0]) return@addOnSuccessListener
                                val face = faces.firstOrNull()
                                if (face != null) {
                                    val ratio = calculateFaceRatio(face)
                                    if (isRegistering) {
                                        viewModel.setFaceDetectionStatus("Face Detected (Ready to Register)")
                                        onFaceRegistered(ratio)
                                    } else {
                                        val regRatio = registeredRatio
                                        if (regRatio != null) {
                                            val diff = kotlin.math.abs(ratio - regRatio)
                                            val isMatch = diff < 0.28f // Adaptive threshold
                                            if (isMatch) {
                                                consecutiveMisses = 0
                                                viewModel.setFaceDetectionStatus("Face Matched")
                                            } else {
                                                viewModel.setFaceDetectionStatus("Unauthorized Face!")
                                                if (faceSecurityEnabled && videoPlaying) {
                                                    consecutiveMisses++
                                                    if (consecutiveMisses >= 8) {
                                                        viewModel.setVideoPlaying(false)
                                                        viewModel.setFaceDetectionStatus("Shield Triggered: Face Mismatch!")
                                                    }
                                                }
                                            }
                                        } else {
                                            viewModel.setFaceDetectionStatus("Face Detected (No Baseline)")
                                        }
                                    }
                                } else {
                                    if (isRegistering) {
                                        viewModel.setFaceDetectionStatus("No Face Found")
                                    } else {
                                        viewModel.setFaceDetectionStatus("No Face Detected")
                                        if (faceSecurityEnabled && videoPlaying) {
                                            consecutiveMisses++
                                            if (consecutiveMisses >= 8) {
                                                viewModel.setVideoPlaying(false)
                                                viewModel.setFaceDetectionStatus("Shield Triggered: No Face!")
                                            }
                                        }
                                    }
                                }
                            }
                            .addOnFailureListener {
                                if (isDisposed[0]) return@addOnFailureListener
                                viewModel.setFaceDetectionStatus("Detection Error")
                            }
                            .addOnCompleteListener {
                                imageProxy.close()
                            }
                    } else {
                        imageProxy.close()
                    }
                }
                
                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                
                try {
                    cameraProvider.unbindAll()
                    if (!isDisposed[0]) {
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalysis
                        )
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }, ContextCompat.getMainExecutor(ctx))
            
            previewView
        },
        modifier = modifier
    )
}

private fun calculateFaceRatio(face: Face): Float {
    val leftEye = face.getLandmark(FaceLandmark.LEFT_EYE)
    val rightEye = face.getLandmark(FaceLandmark.RIGHT_EYE)
    val noseBase = face.getLandmark(FaceLandmark.NOSE_BASE)
    if (leftEye != null && rightEye != null && noseBase != null) {
        val leftEyePos = leftEye.position
        val rightEyePos = rightEye.position
        val noseBasePos = noseBase.position
        
        val dxEyes = leftEyePos.x - rightEyePos.x
        val dyEyes = leftEyePos.y - rightEyePos.y
        val distEyes = kotlin.math.sqrt(dxEyes * dxEyes + dyEyes * dyEyes)

        val dxEyeNose = leftEyePos.x - noseBasePos.x
        val dyEyeNose = leftEyePos.y - noseBasePos.y
        val distEyeNose = kotlin.math.sqrt(dxEyeNose * dxEyeNose + dyEyeNose * dyEyeNose)

        if (distEyeNose > 0f) {
            return distEyes / distEyeNose
        }
    }
    val box = face.boundingBox
    if (box.height() > 0) {
        return box.width().toFloat() / box.height().toFloat()
    }
    return 1.0f
}
